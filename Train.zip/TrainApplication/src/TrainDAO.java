package casestudy1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TrainDAO {

	String Drivername;
	String DB_URL;
	String Username;
	String Password;

	TrainDAO(){};

	public TrainDAO(String drivername, String dB_URL, String username, String password) {
		super();
		Drivername = drivername;
		DB_URL = dB_URL;
		Username = username;
		Password = password;
	}

	public String getDrivername() {
		return Drivername;
	}

	public void setDrivername(String drivername) {
		Drivername = drivername;
	}

	public String getDB_URL() {
		return DB_URL;
	}

	public void setDB_URL(String dB_URL) {
		DB_URL = dB_URL;
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public Train findTrain(int Trainno) throws ClassNotFoundException, SQLException {

		//step 1 - register the driver
		Class.forName("oracle.jdbc.OracleDriver");

		//Step 2 - establish a connection
		Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "hr", "nikhil");

		//Step 3 - create a statement
		Statement statement = connection.createStatement();

		//Step 4 - pass the SQL query and get the result

		ResultSet resultSet;
		try {
			resultSet = statement.executeQuery("SELECT * FROM TRAINS WHERE TRAINNO =" +Trainno);
			resultSet.next();
			Train t1 = new Train();
			t1.setTrainno(resultSet.getInt(1));
			t1.setTrainname(resultSet.getString(2));
			t1.setSource(resultSet.getString(3));
			t1.setDestination(resultSet.getString(4));
			t1.setTicketPrice(resultSet.getDouble(5));
			return t1;
		}
		catch(SQLException e) {

			System.out.println("this train number doesnt exists");
			return null;
		}
	}
}


